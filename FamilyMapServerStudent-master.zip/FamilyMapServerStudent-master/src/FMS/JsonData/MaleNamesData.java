package JsonData;

public class MaleNamesData {
    String [] data;

    public MaleNamesData(String[] data) {
        this.data = data;
    }

    public String[] getData() {
        return data;
    }

    public void setData(String[] data) {
        this.data = data;
    }
}
