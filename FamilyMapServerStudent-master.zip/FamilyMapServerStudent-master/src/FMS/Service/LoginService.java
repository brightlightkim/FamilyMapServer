package Service;

import DataAccess.AuthTokenDAO;
import DataAccess.Database;
import DataAccess.UserDAO;
import Error.DataAccessException;
import Model.AuthToken;
import Model.User;
import Request.LoginRequest;
import Result.LoginResult;

import java.util.UUID;

/**
 * Class that performs the login
 */
public class LoginService {
    /**
     * Performs the login and show the result
     * @param request of LoginRequest with username and password
     * @return login result
     */
    public LoginResult login(LoginRequest request) throws DataAccessException {
        Database db = new Database();
        try{
            db.getConnection();

            if (request.getUsername() == null || request.getPassword() == null){
                LoginResult result = new LoginResult("Error: request field is not filled", false);
                db.closeConnection(false);
                return result;
            }

            // Use DAOs to do requested operation
            User matchedUser = new UserDAO(db.getConnection()).find(request.getUsername());

            if (matchedUser == null){
                LoginResult result = new LoginResult("Error: No ID that match", false);
                db.closeConnection(false);
                return result;
            }

            //when the password not match
            if (!matchedUser.getPassword().equals(request.getPassword())){
                LoginResult result = new LoginResult("Error: Password not match", false);
                db.closeConnection(false);
                return result;
            }

            db.closeConnection(true);

            //Then I have to create the Authorization token and insert it.
            String uuid = UUID.nameUUIDFromBytes(request.getUsername().getBytes()).toString();
            AuthToken token = new AuthToken(uuid, request.getUsername());
            db.getConnection();
            new AuthTokenDAO(db.getConnection()).insert(token);
            // Close database connection, COMMIT transaction
            db.closeConnection(true);

            // Create and return SUCCESS Result object
            LoginResult result = new LoginResult(uuid, matchedUser.getUsername(), matchedUser.getPersonID(),true);
            return result;
        }
        catch (Exception ex) {
            ex.printStackTrace();

            // Close database connection, ROLLBACK transaction
            db.closeConnection(false);

            // Create and return FAILURE Result object

        }

        return null;
    }
}
